# CS310-ProjectOne

<strong>Guide to Test bufferedImage.jsp</strong>

  After you pull, you can find <strong>bufferedImage.jsp</strong> inside <strong>WebContent/bufferedImageTest</strong>. In order to test the file, you need to have a test image so the BufferedImage object can be created. See <strong>ImageServlet.java</strong> for details. <strong>ImageServlet.java</strong> is located in <strong>src/bufferedImageTest</strong>. 
