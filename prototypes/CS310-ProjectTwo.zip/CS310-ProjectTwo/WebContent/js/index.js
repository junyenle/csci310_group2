// When document is ready bind the event listeners
$(document).ready( () => {
    // Attach the search button listener
    $('#searchbutton').click(buildCollage);

    // Permit the enter key
    $(document).keyup(permitEnterKey);

    // Check if the search box is empty or not
    $('#searchtext').keyup(disableSearchButton);
});

// Permit the Enter key to search and build the collage
let permitEnterKey = (e) => {
    var key = e.keyCode ? e.keyCode : e.which;
    if (key == 13) {
        $('#searchbutton').click();
    }  
}

// Call server to build the collage
let buildCollage = () => {
    const term = $('#searchtext').val();
    const shape = $('#shapetext').val();
    const browserWidth = $(window).width();
    const browserHeight = $(window).height();
    console.log(term);
    console.log(shape);

    // Perform the AJAX call to servlet
    $.ajax({
        type: "GET",
        url: "collageBuilderServlet",
        data: {
            searchText: term,
            shapeText: shape, 
            browserWidth: browserWidth,
            browserHeight: browserHeight
        },
        success: (response) => {
            console.log('success');
            window.location.href = "collage.jsp";
        }
    });
}

// Disable the search button when there is no text
let disableSearchButton = () => {

    // Check if the term was inputted
    const searchTerm = $('#searchtext').val();
    if (searchTerm.length > 0) {
        // Removes the disabled attribute
        $('#searchbutton').removeAttr("disabled");
    }
    else {
        // Disables the build button
        $('#searchbutton').attr("disabled", "true");
    } 
}

