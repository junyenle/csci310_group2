$(document).ready( () => {
    let usernameField = $('#username')[0];
    let passwordField = $('#password')[0];
    let loginButton = $('#loginbutton')[0];

    $(loginButton).click( () => {
        let username = $(usernameField).val();
        let password = $(passwordField).val();

        $.ajax({
            type: "GET",
            url: "loginServlet",
            data: {
                username: username,
                password: password
            },
            success: (response) => {
                console.log(response);
                if (response == "success") {
                    window.location.href = "index.jsp";
                }
                else {
                    console.log("There was a login error.");
                }
            }
        });
    });
});