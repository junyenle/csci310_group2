import java.util.Vector;

public class Utility {
// Utility class
	
	// constructs the coordinate grid for a given char. used by collage builder.
	public Vector<Boolean> constructGrid(char charToBuild) 
	{
		Vector<Boolean> grid = new Vector<Boolean>();
		
		// determine what that character is, and fill grid accordingly
		if(charToBuild==' ') {
			for(int j = 0; j < 64; j++) {
				grid.add(false);
			}
		} // end if ' '
		
		if(charToBuild=='A') {
			for(int j = 0; j < 11; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 6; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			grid.add(false);
			grid.add(false);
			grid.add(false);
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 9; j++){
				grid.add(false);
			}
		} // end if 'A'
		
		if(charToBuild=='B') {
			for(int j = 0; j < 10; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 10; j++){
				grid.add(false);
			}
		} // end if 'B'
		
		if(charToBuild=='C') {
			for(int j = 0; j < 10; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 7; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 7; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 11; j++){
				grid.add(false);
			}
		} // end if 'C'
		
		if(charToBuild=='D') {
			for(int j = 0; j < 9; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 12; j++){
				grid.add(false);
			}
		} // end if 'D'
		
		if(charToBuild=='E') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if 'E'
		
		if(charToBuild=='F') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if 'F'
		
		if(charToBuild=='G') {
			for(int j = 0; j < 10; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 7; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(false);
			grid.add(true);
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 9; j++){
				grid.add(false);
			}
		} // end if 'G'
		
		if(charToBuild=='H') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if 'H'
		
		if(charToBuild=='I') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "I"
		
		if(charToBuild=='J') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "J"
		
		if(charToBuild=='K') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "K"

		if(charToBuild=='L') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "L"

		if(charToBuild=='M') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);

			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(true);
			grid.add(false);
			
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(true);
			grid.add(false);

			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "M"
		
		if(charToBuild=='N') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}

			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);

			grid.add(false);
			grid.add(true);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(true);
			grid.add(false);
			
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "N"
		
		if(charToBuild=='O') {
			for(int j = 0; j < 10; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 11; j++){
				grid.add(false);
			}
		} // end if 'O'
		
		if(charToBuild=='P') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			grid.add(false);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			grid.add(false);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}

			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
		} // end if 'P'
		
		if(charToBuild=='Q') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if 'Q'
		
		if(charToBuild=='R') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			grid.add(false);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			grid.add(false);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
		} // end if 'R'
		
		if(charToBuild=='S') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}			

			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}		
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}		
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}		
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}		
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}		
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
		} // end if 'S'

		if(charToBuild=='T') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}			

			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 5; j++){
				grid.add(true);
			}
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
		} // end if 'T'
		
		if(charToBuild=='U') {
			for(int j = 0; j < 9; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 11; j++){
				grid.add(false);
			}
		} // end if 'U'
		
		if(charToBuild=='V') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if 'V'

		if(charToBuild=='W') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}

			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);

			
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			grid.add(true);
			grid.add(false);	

			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(true);
			grid.add(false);
			
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "W"
		

		if(charToBuild=='X') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}

			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}			

			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 0; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 0; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		

			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "X"

		if(charToBuild=='Y') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}			

			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			

			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
		} // end if 'Y'

		if(charToBuild=='Z') {
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
			
			grid.add(false);
			for(int j = 0; j < 6; j++){
				grid.add(true);
			}
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}

			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(false);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}			

			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(false);
			for(int j = 0; j < 0; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 0; j++){
				grid.add(false);
			}
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}

			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			grid.add(false);
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}		

			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			grid.add(true);
			for(int j = 0; j < 1; j++){
				grid.add(false);
			}
			
			for(int j = 0; j < 8; j++){
				grid.add(false);
			}
		} // end if "Z"
		
		
		return grid;
	} // end constructGrid()
	
	
	
}
