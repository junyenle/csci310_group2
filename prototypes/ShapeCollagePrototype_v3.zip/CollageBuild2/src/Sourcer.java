import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class Sourcer {
	public BufferedImage getImage() {
		
		BufferedImage image = new BufferedImage(500, 300, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = image.createGraphics();
		int randNum = (int) (Math.random() * 4);
		Color color = Color.red;
		if(randNum == 0) {
			color = Color.yellow;
		}
		if(randNum == 1) {
			color = Color.red;
		}
		if(randNum == 2) {
			color = Color.green;
		}
		if(randNum == 3) {
			color = Color.blue;
		}
		if(randNum == 4) {
			color = Color.black;
		}
		g2d.setColor(color);
		g2d.fill(new Rectangle2D.Float(0,0,500,300));
		
		return image;
	}
}
