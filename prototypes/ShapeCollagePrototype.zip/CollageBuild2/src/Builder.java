import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Vector;

import javax.imageio.ImageIO;

public class Builder {

	public static void main(String[] args) {
		String shapeString = "AAA";
		int collageWidth = 1200;
		int collageHeight = 400;
		Builder builder = new Builder();
		
		try {
			Sourcer s = new Sourcer();
			BufferedImage bi = builder.buildCollage(shapeString, collageWidth, collageHeight);
			File ofile = new File("test.png");
			ImageIO.write(bi,  "png",  ofile);
			System.out.println("printed succesfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public BufferedImage buildCollage(String shape, int collageWidth, int collageHeight) {
		// determine whether height or width is limiting factor
		int gridSideLength = 0;
		if(collageWidth / shape.length() > collageHeight) {
			// height is limiting factor
			gridSideLength = collageHeight;
		}
		else {
			// width is limiting factor
			gridSideLength = collageWidth / shape.length();
		}
		
		// each grid square is 1/8 of total grid side
		int gridSquareSideLength = gridSideLength/8;
		
		// array of character bufferedimages
		Vector<BufferedImage> characterImages = new Vector<BufferedImage>();
		
		// for each character
		for(int i = 0; i < shape.length(); i++) {
			// create vector "grid"
			Vector<Boolean> grid = new Vector<Boolean>();
			
			// determine what that character is, and fill grid accordingly
			if(shape.charAt(i)=='A') {
				for(int j = 0; j < 10; j++){
					grid.add(false);
				}
				for(int j = 0; j < 3; j++){
					grid.add(true);
				}
				for(int j = 0; j < 5; j++){
					grid.add(false);
				}
				grid.add(true);
				grid.add(false);
				grid.add(true);
				for(int j = 0; j < 5; j++){
					grid.add(false);
				}
				grid.add(true);
				grid.add(false);
				grid.add(true);
				for(int j = 0; j < 4; j++){
					grid.add(false);
				}
				for(int j = 0; j < 5; j++){
					grid.add(true);
				}
				for(int j = 0; j < 3; j++){
					grid.add(false);
				}
				for(int j = 0; j < 2; j++){
					grid.add(true);
				}
				grid.add(false);
				for(int j = 0; j < 2; j++){
					grid.add(true);
				}
				for(int j = 0; j < 3; j++){
					grid.add(false);
				}
				for(int j = 0; j < 2; j++){
					grid.add(true);
				}
				for(int j = 0; j < 2; j++){
					grid.add(false);
				}
				for(int j = 0; j < 2; j++){
					grid.add(true);
				}
				for(int j = 0; j < 9; j++){
					grid.add(false);
				}
			} // end if 'A'
			
			
			// create the character image
			BufferedImage characterImage = new BufferedImage(gridSideLength, gridSideLength, BufferedImage.TYPE_INT_ARGB);		
			Graphics2D g2d = characterImage.createGraphics();
			g2d.setColor(Color.white);
			g2d.fill(new Rectangle2D.Float(0,0,gridSideLength,gridSideLength));
			
			for(int k = 0; k < 64; k++) {
				if(grid.get(k) == true) {
					// find appropriate grid coordinates
					int xcoord = k%8 * gridSquareSideLength;
					int ycoord = k/8 * gridSquareSideLength;
					
					// slightly randomize grid coordinates
					int acceptableOffsetScale = 4;
					Random randomOffsetter = new Random();
					xcoord = xcoord + (int)(randomOffsetter.nextInt(gridSquareSideLength / acceptableOffsetScale) - (gridSquareSideLength / acceptableOffsetScale / 2));
					ycoord = ycoord + (int)(randomOffsetter.nextInt(gridSquareSideLength / acceptableOffsetScale) - (gridSquareSideLength / acceptableOffsetScale / 2));
					
					// get source image
					Sourcer s = new Sourcer();
					BufferedImage sourceImage = s.getImage();
					
					// resize image
					// check whether height or width is larger.. we will scale this down
					int sourceWidth = sourceImage.getWidth();
					int sourceHeight = sourceImage.getHeight();
					int scaledWidth = 0;
					int scaledHeight = 0;
					if(sourceWidth > sourceHeight) {
						// most likely case.. we need to determine the appropriate height scale
						scaledHeight = (int)(((float)gridSquareSideLength / sourceWidth) * sourceHeight);
						// and desired width is just gridlength
						scaledWidth = gridSquareSideLength;
					}
					else {
						// unlikely case.. determine appropriate width scale
						scaledWidth = (int)(((float)gridSquareSideLength / sourceHeight) * sourceWidth);
						// and desired height is just gridlength
						scaledHeight = gridSquareSideLength;
					}
					// actual resize now
					double bloatModifier = 1.2;
					sourceImage = getScaledImage(sourceImage, (int)(scaledWidth * bloatModifier), (int)(scaledHeight * bloatModifier));
					
					// add padding
					sourceImage = addPadding(sourceImage);
					
					// rotate image
					Random randomRotator = new Random();
					int randNum = randomRotator.nextInt(90)- 45;
					sourceImage = rotateImage(sourceImage, randNum);
					
					// draw image on top of bufferedimage
					g2d.drawImage(sourceImage,  xcoord,  ycoord,  null);
				}
			}
			// add new character image to vector
			characterImages.add(characterImage);
									
		} // end for each character
		
		// create large bufferedimage for entire shape
		BufferedImage collage = new BufferedImage(collageWidth, collageHeight, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = collage.createGraphics();
		g2d.setColor(Color.white);
		g2d.fill(new Rectangle2D.Float(0,0,collageWidth,collageHeight));
		
		// draw all the character images
		for(int i = 0; i < characterImages.size(); i++) {
			g2d.drawImage(characterImages.get(i), i * gridSideLength, 0, null);
		}
		
		return collage;
	} // buildCollage end
	
    // Rotates the given image by the given number of degrees and returns BufferedImage
    public BufferedImage rotateImage(BufferedImage src,int inDegrees) {
        // Calculate the width and height of the rotated image
        double rad = Math.toRadians(inDegrees);
        double sin = Math.abs(Math.sin(rad)), cos = Math.abs(Math.cos(rad));
        int srcWidth = src.getWidth(), srcHeight = src.getHeight();
        int rotWidth = (int)Math.floor(srcWidth*cos+srcHeight*sin), rotHeight = (int) Math.floor(srcHeight*cos + srcWidth*sin);
       
        // Rotate the image using Graphics2D
        BufferedImage rotatedImage = new BufferedImage(rotWidth, rotHeight,
                BufferedImage.TRANSLUCENT);
        Graphics2D g2d = rotatedImage.createGraphics();
        g2d.rotate(Math.toRadians(inDegrees), rotWidth/2, rotHeight/2);
        g2d.drawImage(src, (rotWidth-srcWidth)/2, (rotHeight-srcHeight)/2, null);
        g2d.dispose();
        return rotatedImage;
    }
	
    // scales the image based on desired width and height
    private BufferedImage getScaledImage(BufferedImage src, int width, int height){
        int srcWidth = src.getWidth();
        int srcHeight = src.getHeight();
        BufferedImage scaledImage = new BufferedImage(width, height, BufferedImage.TRANSLUCENT);
       
        // Scale image according to the ratio of the original image to new scaled image
        AffineTransform scaleOp = new AffineTransform();
        scaleOp.scale(width/(double)srcWidth, height/(double)srcHeight);
   
        // Use Graphics2D to complete the scaling
        Graphics2D g2d = scaledImage.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setTransform(scaleOp);
        g2d.drawImage(src, 0, 0, null);
        g2d.dispose();
       
        return scaledImage;
    }
    
    // Add white padding of imagePadding pixels around given image
    private BufferedImage addPadding(BufferedImage src) {
    	int imagePadding = 3;
        int srcWidth = src.getWidth(), srcHeight = src.getHeight();
        int paddedWidth = srcWidth+imagePadding*2, paddedHeight = srcHeight+imagePadding*2;
       
        // Create a white rectangle based on calculated width and height and draw image on top
        BufferedImage paddedImage = new BufferedImage(paddedWidth, paddedHeight, src.getType());
        Graphics2D g2d = paddedImage.createGraphics();
        g2d.setColor(Color.black);
        g2d.fillRect(0, 0, paddedWidth, paddedHeight);
        g2d.drawImage(src, imagePadding, imagePadding, null);
        g2d.dispose();
        return paddedImage;
    }
    
}
