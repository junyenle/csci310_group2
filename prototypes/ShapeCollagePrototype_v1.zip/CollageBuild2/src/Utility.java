import java.util.Vector;

public class Utility {
// Utility class
	
	// constructs the coordinate grid for a given char. used by collage builder.
	public Vector<Boolean> constructGrid(char charToBuild) 
	{
		Vector<Boolean> grid = new Vector<Boolean>();
		
		// determine what that character is, and fill grid accordingly
		if(charToBuild==' ') {
			for(int j = 0; j < 64; j++) {
				grid.add(false);
			}
		} // end if ' '
		
		if(charToBuild=='A') {
			for(int j = 0; j < 11; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 6; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}
			grid.add(false);
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}
			for(int j = 0; j < 2; j++){
				grid.add(false);
			}
			for(int j = 0; j < 2; j++){
				grid.add(true);
			}
			for(int j = 0; j < 9; j++){
				grid.add(false);
			}
		} // end if 'A'
		
		if(charToBuild=='B') {
			for(int j = 0; j < 10; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 4; j++){
				grid.add(true);
			}
			for(int j = 0; j < 10; j++){
				grid.add(false);
			}
		} // end if 'B'
		
		if(charToBuild=='C') {
			for(int j = 0; j < 10; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 7; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 7; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			for(int j = 0; j < 4; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 11; j++){
				grid.add(false);
			}
		} // end if 'C'
		
		if(charToBuild=='D') {
			for(int j = 0; j < 9; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 5; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 1; j++){
				grid.add(true);
			}
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			grid.add(true);
			grid.add(false);
			grid.add(false);
			grid.add(true);
			grid.add(false);
			for(int j = 0; j < 3; j++){
				grid.add(false);
			}
			for(int j = 0; j < 3; j++){
				grid.add(true);
			}
			for(int j = 0; j < 12; j++){
				grid.add(false);
			}
		} // end if 'D'
		
		return grid;
	} // end constructGrid()
	
	
	
}
