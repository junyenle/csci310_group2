
public class PracticeMain {
	public static void main(String[] args) {
		HTMLGenerator htmlGen = new HTMLGenerator();
		
		System.out.println(htmlGen.generateHTML("hello"));
	}
}
